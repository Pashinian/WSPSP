import java.util.ArrayList;

public class Casa {

	private Direccion direccion;
	private Personas propietario;
	private Personas inquilino;
	private ArrayList<Habitaciones> habitaciones;
	private int metros;

	public Casa(Direccion direccion, ArrayList<Habitaciones> habitaciones, Personas propietario, Personas inquilino,
			double metros) {
		super();
		this.direccion = direccion;
		this.habitaciones = habitaciones;
		this.propietario = propietario;
		this.inquilino = inquilino;
		this.metros = (int) metros;
	}

	@Override
	public String toString() {
		return "Casa = " + direccion.toString() + "Habitaciones = " + habitaciones.toString() + "Propietario = "
				+ propietario.toString() + " Inquilino = " + inquilino.toString() + " Metros cuadrados = " + metros;
	}
}
