
public class Personas {

	private String nombre;
	private int dni;
	private int telefono;
	private Direccion direccion;

	public Personas(String nombre, int dni, int telefono, Direccion direccion) {
		super();
		this.nombre = nombre;
		this.dni = dni;
		this.telefono = telefono;
		this.direccion = direccion;
	}

	@Override
	public String toString() {
		return "Nombre =" + nombre + " DNI = " + dni + " Telefono = " + telefono + " Direccion = " + direccion;
	}
}
