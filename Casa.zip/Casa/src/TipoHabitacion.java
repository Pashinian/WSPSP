
public enum TipoHabitacion {
	COCINA, DORMITORIO, BANO, SALON
}
