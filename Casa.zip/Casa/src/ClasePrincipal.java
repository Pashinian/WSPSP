import java.util.ArrayList;

public class ClasePrincipal {

	static ArrayList<Habitaciones> habitaciones = new ArrayList<Habitaciones>();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Direccion direccionCasa = new Direccion("Avenida", "Madrid", 28670, 1);
		Direccion direccionPropietario = new Direccion("Calle", "Tajo", 28670, 12);

		Personas propietario = new Personas("Pepe", 12345678, 12346567,  direccionPropietario);
		Personas inquilino = new Personas("Kiko", 12346567, 12345678, direccionCasa);

		Habitaciones cocina = new Habitaciones(TipoHabitacion.COCINA, 20, 1);
		Habitaciones dormitorio = new Habitaciones(TipoHabitacion.DORMITORIO, 15, 2);
		Habitaciones dormitorio2 = new Habitaciones(TipoHabitacion.DORMITORIO, 15, 3);
		Habitaciones dormitorio3 = new Habitaciones(TipoHabitacion.DORMITORIO, 15, 4);
		Habitaciones bano = new Habitaciones(TipoHabitacion.BANO, 10, 5);
		Habitaciones bano2 = new Habitaciones(TipoHabitacion.BANO, 10, 6);
		Habitaciones salon = new Habitaciones(TipoHabitacion.SALON, 40, 7);
		
	
		habitaciones.add(cocina);
		habitaciones.add(dormitorio);
		habitaciones.add(dormitorio2);
		habitaciones.add(dormitorio3);
		habitaciones.add(bano);
		habitaciones.add(bano2);
		habitaciones.add(salon);
		

		
		Casa casoplon = new Casa(direccionCasa, habitaciones, propietario, inquilino, metrosCuadrados());
		System.out.println(casoplon.toString());

	}
	private static double metrosCuadrados() {
		// TODO Auto-generated method stub
		double m = 0;
		for (int i = 0; i < habitaciones.size(); i++) {

			m += habitaciones.get(i).getMetros();
		}
		return m;
	}

}
