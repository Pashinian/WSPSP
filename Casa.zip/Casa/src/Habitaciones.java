
public class Habitaciones {

	private TipoHabitacion tipo;
	private double metros;
	private int num;

	public Habitaciones(TipoHabitacion tipo, int metros, int num) {
		super();
		this.tipo = tipo;
		this.metros = metros;
		this.num = num;
	}

	@Override
	public String toString() {
		return "Tipo = " + tipo + " Metros = " + metros + " Numero de Habitacion = " + num;
	}
	public double getMetros() {
		return metros;
	}
}
