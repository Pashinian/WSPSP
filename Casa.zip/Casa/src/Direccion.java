
public class Direccion {
	private String tipovia;
	private String calle;
	private int cp;
	private int num;

	public Direccion(String tipovia, String calle, int cp, int num) {
		super();
		this.tipovia = tipovia;
		this.calle = calle;
		this.cp = cp;
		this.num = num;
	}

	@Override
	public String toString() {
		return "Tipo de via = " + tipovia + " Calle = " + calle + " cp = " + cp + " Numero = " + num;
	}
}
